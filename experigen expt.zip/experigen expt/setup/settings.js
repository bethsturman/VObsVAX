var Experigen =  {
	settings: {

		experimentName: "VObsVAX", // use only A-Z, a-z, 0-9 ATBPhonMorphLang2 or DEEPhonMorphLang2 or ATBMorphL2Nov""ATBL2ExclFillers" "ATBL2Explicit"
		
		databaseServer: "http://db.phonologist.org/",

		online: true, // make sure you know what you're doing before changing this
		
		strings: {
			windowTitle:     "Sound discrimination task",
			connecting:		 "Connecting...",
			loading:         "Loading...",
			soundButton:     "    ►    ",
			continueButton:  "   continue   ",
			errorMessage:    "An error occurred. We apologize for the inconvenience.",
			emptyBoxMessage: "Please supply your answer in the text box."
		},
		
		audio: true,
		
		recordResponseTimes: true,
		
		progressbar: {
			visible: true, 
			adjustWidth: 0.3,
			percentage: true
		},
		
		items: "resources/items.txt",
		
		otherresources: {
			frames: "resources/frames.txt",
			pictures: "resources/pictures.txt"	
		},

		folders: {
			views: "views/",
			sounds: "resources/sounds/",
			pictures: "resources/pictures/",
			plugins: "plugins/"
		},

		plugins: ["abx", "presskey", "reportsounderror", "vas_slider", "wavhtml5", "soundman", "timer", "playntimes"],
	
		footer: "views/footer.html",
		missingview: "views/missingview.ejs"
	}	
};


