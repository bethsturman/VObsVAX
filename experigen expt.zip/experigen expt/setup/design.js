Experigen.initialize = function () {
	
	var items  = this.resource("items");
    
    var block_intro = []
			.concat(items.subset("phase", "intro"))
			.pairWith("view", "stimulus_perceptual_init.ejs")
			.shuffle()
			;
    
    var block_perceptual_init = []
			.concat(items.subset("phase", "perceptual1"))
			.pairWith("view", "stimulus_perceptual_init.ejs")
			.shuffle()
			;
    
    var block_perceptual2 = []
			.concat(items.subset("phase", "perceptual2")
                   
                   )
			.pairWith("view", "stimulus_perceptual_init.ejs")
			.shuffle()
			;

				
// 	Use this to save other column
	Experigen.fieldsToSave["trialnb"] = true;
	Experigen.fieldsToSave["trialtype"] = true;
//    Experigen.fieldsToSave["VCV1"] = true;
//    Experigen.fieldsToSave["VCV2"] = true;
//    Experigen.fieldsToSave["V2"] = true;

		
// This part is where you put in the order of the experiment	
    
    this.addStaticScreen("consent.ejs");
    
    this.addStaticScreen("inst_perceptual.ejs"); 
    this.addBlock(block_intro);
    
    this.addStaticScreen("inst_perceptual.ejs"); 
    this.addBlock(block_perceptual_init);

    this.addStaticScreen("inst_perceptual.ejs"); 
    this.addBlock(block_perceptual2);
//    
	this.addStaticScreen("demographic.ejs");
	this.addStaticScreen("finalthanks_psych.ejs");
	this.progressbar.addSectionBreak() 
	
}