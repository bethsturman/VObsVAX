//soundManager.url = '_lib/soundman/swf/';
//soundManager.debugMode = false;


soundManager.setup({
  url: '_lib/soundman/swf/',
  onready: function() {
    // Ready to use; soundManager.createSound() etc. can now be called.
  }
});

