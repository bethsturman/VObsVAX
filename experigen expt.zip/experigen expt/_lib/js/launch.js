/** @file Simply launches the experiment */
//var exp = new Experiment();
Experigen.launch();